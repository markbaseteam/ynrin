
| Activiteiten 2024       | 27-8 | 8-9 | 15-9 | 29-9 | NF 7-10 | 20-10 | 3-11 | 17-11 | 1-12 |
| -------------------------- | ---- | --- | ---- | ---- | ------- | ----- | ---- | ----- | ---- |
| 18 sept. Kunst en Cultuur  | X    | X   | X    |      |         |       |      |       |      |
| 2 okt. Landbouw en Voedsel |      | X   | X    | X    |         |       |      |       |      |
| 16 okt. Toerisme en Sûnens |      |     | X    | X    | X       |       |      |       |      |
| 30 okt. Water              |      |     |      | X    | X       | X     |      |       |      |
| 13 nov. Onderwijs/training |      |     |      |      | X       | X     | X    |       |      |
| 27 nov. Wearde             |      |     |      |      | X       | X     | X    |  X     |      |
| 11 dec. Energie            |      |     |      |      |         |       | X    | X     |  X   |


| Ynrin datum en thema       | 27-8 | 8-9 | 15-9 | 29-9 | NF 7-10 | 20-10 | 3-11 | 17-11 | 1-12 |
| -------------------------- | ---- | --- | ---- | ---- | ------- | ----- | ---- | ----- | ---- |
| 18 sept. Kunst en Cultuur  | X    | X   | X    |      |         |       |      |       |      |
| 2 okt. Landbouw en Voedsel |      | X   | X    | X    |         |       |      |       |      |
| 16 okt. Toerisme en Sûnens |      |     | X    | X    | X       |       |      |       |      |
| 30 okt. Water              |      |     |      | X    | X       | X     |      |       |      |
| 13 nov. Onderwijs/training |      |     |      |      | X       | X     | X    |       |      |
| 27 nov. Wearde             |      |     |      |      | X       | X     | X    |  X     |      |
| 11 dec. Energie            |      |     |      |      |         |       | X    | X     |  X   |


## Nieuwsbrief 27 AUG - VERZONDEN
1. Aankondiging Kunst en Cultuur Ynrin/thema-avond. 
2. Lanceringstekst Kunst en Cultuur --> thema online 
3. Vlaggenactie met foto's 
4. Thema-avonden (zie ook tekst Nijs en Updates) aankondigen breed 
5. Kort verslag jongerenweek (toestemming wordt nu gevraagd) 
6. Video 'Op 'e bank mei.. Jan'
7. Verslag bijeenkomsten zorgondernemers

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/27B9612E721F1E6B2540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 8 SEPT - VERZONDEN 10 september
Google Link om content aan te leveren:
https://docs.google.com/document/d/18Bj45ZrVXytUmj5cCRxT2sVr1Nt1zdrm5JrQQe8pKok/edit?usp=sharing
1. Aanpassing thema -> Landbouw en voedselzekerheid
	1. Thematekst aanpassen op website 
	   **(Han/Nynke/Pi)**
2. Aankondiging thema-avond voor boeren en andere betrokkenen
	1. Ook persoonlijke uitnodigingen sturen aan boeren en andere betrokkenen
	   **(Nynke, Pi)**
3. Aankondigen Kunst en Cultuur nogmaals 
	   **(Han)**
	1. Ook oproepen mee te doen
5. Voorstellen boer Bart (met artikel en video)
	1. Format opstellen (video kan eventueel een video van zijn huidige YT-kanaal zijn)
	   **(Nynke)** 
	2. Artikel
	   **(Han, Nynke, Pi)**

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/3D19BF2777A9D3252540EF23F30FEDED/C67FD2F38AC4859C/ 

## Nieuwsflits 15 SEPT - VERZONDEN 18 september
Google Link om content aan te leveren:
https://docs.google.com/document/d/1U5iepShLMrKzSMZtNrPgYuStFcrvCDX35_QM9YNsp_g/edit?usp=sharing
1. Voorstellen Gjalt en Leonne bedrijf (beelden maken tijdens Oanjeierspicknick)
	1. Naar format, eventueel video maken?
2. Aankondiging Kunst en Cultuur
3. Aankondiging Landbouw en Voedselzekerheid
4. Aankondiging Bedrijvenavond (?)

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/C39B725D297C478E2540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 27/29 SEPT - VERZONDEN
https://docs.google.com/document/d/1dPPuzZV6KENh3RaGF8x3TCjHzq-zARjpGNtciam_m1o/edit?usp=drive_link
1. Voorstellen Graanbroeders (beelden maken tijdens oogstfeest voor eventuele video)
	1. Naar zelfde format als vorige twee artikelen
	2. twee andere boeren herhalen
2. Aankondiging Landbouw en Voedselzekerheid (ook melden opgeven weckworkshop)
3. Aankondigen (en lanceren thema) Water en thema-avond
4. Kort artikel over School of Understanding (+ contacteren Bonne over langer artikel, eventueel eigen ervaringen). https://publish.obsidian.md/school-of-understanding/School-of-understanding/Welcome
5. Aankondiging Bedrijvenavond (?) - DOEN WE NIET (evt wel gezondheidsbedrijven, afstemmen met akke/ellen)
6. Kunst & Cultuur werven leden werkgroep
7. Aankondigen 13. nov + Aanbod Tjeerd (komende twee weken) onder de aandacht brengen
8. Eventueel onder aandacht brengen van voorstelling in Riis

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/E1B8F90297A9A68C2540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsflits 7 OKT - VERZONDEN 6 oktober
1. Agenda OKT en NOV
2. Aankondiging Toerisme App bijeenkomst
3. Aankondiging ondernemers in de zorg bijeenkomst

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/714A0FDD43903EDA2540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 20 OKT - VERZONDEN 22 oktober
1. **Aankondiging Water thema-avond + lezing Theo Claassen** (eventueel link naar boek/film) - zie input Theo CL **(Han/Pi)**
   https://docs.google.com/document/d/1FrZL8sI21jIHEmkWdc5sQh0HML1ga0F9pvtZ3zZCWrA/edit?usp=sharing
   **MP3**: https://echoesofpeace.org/track/1736100/water-is-life
   **Notatie:** https://bzglfiles.s3.ca-central-1.amazonaws.com/u/165323/86d889e381752c90a487ec6433a65531f8deb8d6/original/water-is-life-melody.pdf?response-content-type=application%2Fpdf&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIA2AEJH4L527DJJBYE%2F20231019%2Fca-central-1%2Fs3%2Faws4_request&X-Amz-Date=20231019T080415Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=29e8435ac31c70335d152f15612d285404e4f2e0f8d95e484e39103bdab2394b
2. **Aankondiging 13 november:** Tjeerd Andringa en Michaela Schippers (programma ook in artikel online zetten, ook met Sacred Dance)
	1. Arikel Tjeerd / school of understanding **(Han/Pi/Bonne)** - in de maak, Bonne heeft e.e.a. aangeleverd
4. Verslag 2 oktober boerenfinanciën?? **(Nynke?)** - in de maak - bijna klaar
    **Hier link:** https://docs.google.com/document/d/1OC_3tkn7-nG6xqE6ZWQB-wb3P4kTNe0W1czhkXikEkc/edit?usp=sharing , zie kop '**Artikel nieuwsbrief**'
5. **Artikel FEB (inpyt Sybren):** https://docs.google.com/document/d/1Djrs9wBwBfiDSGDJhN46FHWpo3uy0Mqp23kmpnegNkw/edit?usp=sharing
6. Niet in nieuwsbrief: Promotie plaatjes Hans Kamperman: link + plaatsen in Nijs en Updates, Landbouw- en Energiemienskip
  
**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/8C1F24C100154F8E2540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 3 NOV - VERZONDEN (5 NOVEMBER)
1. Artikel over werk Michaela **(Han/Pi/Michaëla?)**
2. Artikel met programma met intro en verwijzing naar het artikel over de interactieve lezing (Pi)
3. Artikel over de interactieve lezing van Michaéla en Tjeerd en links naar artikel ‘School of Understanding’ en artikel over Michaéla
4. **(KLAAR)** Uitbreiding artikel School of Understanding met info Tjeerd 
5. Artikel Wearde Han (artikel Maarten later of in andere vorm)
   * https://docs.google.com/document/d/1w3r5jww8vlatlSvznThTu4wJaBaRPSURtkDcbffjXIo/edit
   * Han: 
1. Aankondiging ledendag > **belangrijk**!! (+ papieren brief over strategie, echte leden, doorontwikkeling coöperatie) **(Han/Pi)**
2. Aankondigen Wearde-avond 27 november + ruw overzicht activiteiten (programma indien al bekend in artikel online zetten, anders volgende nieuwsbrief, **Han/Pi/Weardegroep**)
3. Aankondiging 11 december energie
4. Aandacht voor de Friling... en hij is nog steeds te koop!

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/8CD834ECC1AD14782540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 17 NOV - verzonden 19 november
1. Wearde aankondiging + artikel wearde DL II,  **(deel II, Han)**
2. Aankondiging 11 december, artikel KPP **(Han/Pi/Klaas)**
3. Verslag onderwijs 13 november
4. Aankondiging ledendag 17 december
5. Aandacht voor de Friling... en hij is nog steeds te koop!

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/8A469CAB74B4CF942540EF23F30FEDED/C67FD2F38AC4859C/

## Nieuwsbrief 1 DEC - verzonden 3 december
1. Aankondiging 11 december, evt artikel rond electrocultuur of andere energiezaak
2. Werkgroep electrocultuur?
3. Aankondiging ledendag 17 december
4. Gezondheid: 15 januari
5. Gezondheid: 11 december voor ondernemers

**Resultaat**: https://nijsbrief.frij.frl/t/ViewEmailArchive/r/3E11D8C0895491582540EF23F30FEDED/C67FD2F38AC4859C/